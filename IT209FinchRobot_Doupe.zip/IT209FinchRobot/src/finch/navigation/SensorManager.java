package finch.navigation;

public class SensorManager {
    private FinchAdapter robot; // Finch adapter for controlling movement

    public SensorManager(FinchAdapter robot) {
        this.robot = robot;
    }

    // Gets the distance from the ultrasonic sensor.
    public double getDistance() {
        double distance = robot.getDistance(); 
        return distance;
    }

    // Checks if an obstacle is detected in real-time.
    public boolean getObstacleData() {
        double distance = getDistance();
        boolean obstacleDetected = (distance > 0 && distance < 20);
        return obstacleDetected;
    }

    // Gets line sensor data to assist with path following.
    public boolean getLineData() {
        int left = robot.getLeftLineSensor();
        int right = robot.getRightLineSensor();
        boolean lineDetected = (left < 50 || right < 50);
        return lineDetected;
    }
}


