package finch.navigation;
import birdbrain.finch.Finch;

//Calls Finch API to be used throughout classes
public class FinchAdapter {
    private Finch finch;

    public FinchAdapter() {
        finch = new Finch();
    }

    // API for distance sensor
    public double getDistance() {
        return finch.getDistance();
    }

    // Allows Finch to move forward
    public void moveForward(int speed) {
        finch.setMotors(speed, speed);
    }

    // Allows Finch to move backward
    public void moveBackward(int speed) {
        finch.setMotors(-speed, -speed);
    }

    // Allows Finch to turn left
    public void turnLeft(int speed) {
        finch.setMotors(-speed, speed);
    }

      // Allows Finch to turn right
    public void turnRight(int speed) {
        finch.setMotors(speed, -speed);
    }

    // Stops the Finch
    public void stop() {
        finch.setMotors(0, 0);
    }

    // Disconnects the Finch 
    public void disconnect() {
        stop();
        System.out.println("Finch disconnected.");
    }

    // Allows for motor speed of left and right to be set
    public void setMotors(int leftSpeed, int rightSpeed) {
        finch.setMotors(leftSpeed, rightSpeed);
    }

    // Gets the left sensor 
    public int getLeftLineSensor() {
        return finch.getLine("L");
    }

    // Gets the right sensor
    public int getRightLineSensor() {
        return finch.getLine("R");
    }

    // Determines if obstacle is detected by using distance sensor and checks if it is closer than 20cm
    public boolean isObstacleDetected() {
        return getDistance() < 20;
    }

    // Checks if A button was pressed
    public boolean wasButtonPressed() {
        return finch.getButton("A");
    }
    
    // Allows for tail lights to be adjusted
    public void setTailLED(int red, int green, int blue) {
        finch.setTail("all", red, green, blue);
    }

    // Pauses activity for set number of milliseconds
    public void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
