package finch.navigation;

public class ObstacleAvoidance {
    private FinchAdapter robot; // Finch adapter for controlling movement
    private SensorManager sensorManager; // Manages sensor data

    public ObstacleAvoidance(FinchAdapter robot, SensorManager sensorManager) {
        this.robot = robot;
        this.sensorManager = sensorManager;
    }

    public void navigateAround() {
        System.out.println("Obstacle detected! Avoiding...");

        // Set tail LED to yellow when avoiding an obstacle
        robot.setTailLED(100, 100, 0); // Yellow: (Red=100, Green=100, Blue=0)

        robot.stop();
        robot.sleep(500);

        // Step 1: Check left side first
        robot.turnLeft(20); // Turn speed
        robot.sleep(700); // Duration of turning in milliseconds
        double leftDistance = sensorManager.getDistance();
        System.out.println("Left Path Distance: " + leftDistance + " cm");

        boolean goLeft = leftDistance > 40; // If >40 cm, left is clear

        // Step 2: Commit to left or right turn
        if (goLeft) {
            System.out.println("Moving LEFT around the obstacle...");
        } else {
            System.out.println("Left blocked! Moving RIGHT instead...");
            robot.turnRight(40); // Reset and turn right
            robot.sleep(1400); // Double the duration to correct position
        }

        // Step 3: Move 25 cm forward
        System.out.println("Moving 25 cm forward...");
        robot.moveForward(25);
        robot.sleep(2500);
        robot.stop();

        // Step 4: Turn back towards line
        System.out.println("Turning back towards line...");
        if (goLeft) {
            robot.turnRight(20); // Corrects path if it moved left
        } else {
            robot.turnLeft(20); // Corrects path if it moved right
        }
        robot.sleep(700); // Duration of turning in milliseconds
        robot.stop();

        // Step 5: Move 25 cm to clear the obstacle
        System.out.println("Moving 25 cm to drive past obstacle...");
        robot.moveForward(25);
        robot.sleep(2500);
        robot.stop();

        // Step 6: Move forward until the line is detected
        System.out.println("Searching for the path...");
        while (true) {
            int leftSensor = robot.getLeftLineSensor();
            int rightSensor = robot.getRightLineSensor();

            if (leftSensor < 98 || rightSensor < 98) {
                System.out.println("Line found! Resuming tracking...");

                // Turn off the LED once obstacle avoidance is complete
                robot.setTailLED(0, 0, 0); // LED OFF
                
                break;
            }

            robot.setMotors(15, 15); // Move forward slowly
            robot.sleep(500);
        }

        robot.stop();
    }
}












