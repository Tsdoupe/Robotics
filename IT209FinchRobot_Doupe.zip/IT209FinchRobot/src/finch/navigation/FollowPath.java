package finch.navigation;

public class FollowPath {
    private FinchAdapter robot;  // Finch adapter for controlling movement
    private SensorManager sensorManager;  // Manages sensor data
    private int threshold = 98; // Line detection threshold
    private boolean lastSeenLeft = true; // Track last seen line position
    private int lostLineCount = 0; // Counter for detecting the end of the line

    public FollowPath(FinchAdapter robot, SensorManager sensorManager) {
        this.robot = robot;
        this.sensorManager = sensorManager;
    }

    public void followPath() {
        System.out.println("Following path...");

        while (true) {  
            // Always check for obstacles while tracking the line
            if (sensorManager.getObstacleData()) {
                System.out.println("Obstacle detected! Exiting path following...");
                return; // Exit immediately so MainController can handle avoidance
            }

            // Reads the line sensor values
            int leftSensor = robot.getLeftLineSensor();
            int rightSensor = robot.getRightLineSensor();

            // CASE 1: Both sensors detect the line; Move forward smoothly
            if (leftSensor < threshold && rightSensor < threshold) {
                robot.setMotors(20, 20);
                lostLineCount = 0;
                robot.setTailLED(0, 0, 0); // Ensure tail LED is OFF while following the path
            } 
            // CASE 2: Left sensor detects the line; Turn right slightly
            else if (leftSensor < threshold && rightSensor >= threshold) {
                robot.setMotors(18, 24);
                lastSeenLeft = true;
                lostLineCount = 0;
            } 
            // CASE 3: Right sensor detects the line; Turn left slightly
            else if (rightSensor < threshold && leftSensor >= threshold) {
                robot.setMotors(24, 18);
                lastSeenLeft = false;
                lostLineCount = 0;
            } 
            // CASE 4: No sensors detect the line;  Search for it
            else {
                lostLineCount++;
                // System.out.println("Lost the line! Searching...");

                if (lostLineCount < 5) { 
                    if (lastSeenLeft) {
                        robot.setMotors(10, -10); // Rotate left slightly
                    } else {
                        robot.setMotors(-10, 10); // Rotate right slightly
                    }
                } else {
                    // Set tail to red when searching for line
                    robot.setTailLED(100, 0, 0);
                    robot.stop();
                    robot.sleep(500);  // Pauses Finch before searching for line

                    while (true) {
                    	// Continuously search for line until line is found again
                        int newLeft = robot.getLeftLineSensor();
                        int newRight = robot.getRightLineSensor();

                        if (newLeft < threshold || newRight < threshold) {
                            System.out.println("Line found! Resuming path...");
                            robot.setTailLED(0, 0, 0); // Turn off LED once the line is found
                            break; 
                        }

                        // Rotate slowly to find the line again based off last seen location
                        if (lastSeenLeft) {
                            robot.setMotors(-10, 10); 
                        } else {
                            robot.setMotors(10, -10);
                        }
                        robot.sleep(300);  // Allow time for sensor checks
                    }
                }
            }

            robot.sleep(50);  // Small delay to make movement smoother
        }
    }
}

















