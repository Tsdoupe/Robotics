package finch.navigation;

public class MainController {
    private FinchAdapter robot;  // Finch adapter for controlling movement
    private FollowPath pathFollower;  // Handles line following logic
    private ObstacleAvoidance obstacleAvoidance;  // Handles obstacle avoidance logic
    private SensorManager sensorManager;  // Manages sensor data
    private boolean isRunning = true; // Global flag to control execution

    public MainController() {
    	// Initializes all components of the Finch robot
        robot = new FinchAdapter();
        sensorManager = new SensorManager(robot);
        pathFollower = new FollowPath(robot, sensorManager);
        obstacleAvoidance = new ObstacleAvoidance(robot, sensorManager);
    }

    public void startNavigation() {
        System.out.println("Starting navigation...");

        // Runs until A button is pressed
        while (isRunning) { 
            // Stop everything if button "A" is pressed and disconnect
            if (robot.wasButtonPressed()) {
                System.out.println("Button A pressed. Stopping Finch...");
                robot.stop();
                robot.disconnect();
                isRunning = false; 
                break;
            }

            // PRIORITY: Always check for obstacles first
            if (sensorManager.getObstacleData()) {
                System.out.println("Obstacle detected! Engaging avoidance...");
                obstacleAvoidance.navigateAround();
            } else {
                // If no obstacle, continue tracking the path
                pathFollower.followPath();
            }
        }
    }

    // Creates a MainController instance and starts navigation
    public static void main(String[] args) {
        MainController controller = new MainController();
        controller.startNavigation();
    }
}

